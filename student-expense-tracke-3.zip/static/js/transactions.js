const body = document.getElementById("txBody");
const type = document.getElementById("filterType");
const category = document.getElementById("filterCategory");
const msg = document.getElementById("txMessage");
const money = n => "₹" + Number(n).toLocaleString("en-IN",{maximumFractionDigits:2});

async function loadTransactions(){
  const params = new URLSearchParams();
  if(type.value) params.set("type",type.value);
  if(category.value) params.set("category",category.value);
  const rows = await (await fetch("/api/transactions?"+params.toString())).json();
  body.innerHTML = rows.map(x=>`<tr>
    <td>${x.date}</td>
    <td><span class="badge ${x.type==="income"?"badge-income":"badge-expense"}">${x.type}</span></td>
    <td>${x.category}</td><td>${x.note||"-"}</td>
    <td class="fw-semibold">${money(x.amount)}</td>
    <td><button class="btn btn-sm btn-outline-danger" onclick="removeTx(${x.id})"><i class="bi bi-trash"></i></button></td>
  </tr>`).join("") || `<tr><td colspan="6" class="text-center text-muted py-4">No transactions found.</td></tr>`;
}
async function removeTx(id){
  if(!confirm("Delete this transaction?")) return;
  const res = await fetch("/api/transactions/"+id,{method:"DELETE"});
  const data = await res.json();
  msg.innerHTML = `<div class="alert alert-${res.ok?"success":"danger"}">${data.message||data.error}</div>`;
  loadTransactions();
}
[type,category].forEach(x=>x.addEventListener("change",loadTransactions));
document.getElementById("clearFilters").addEventListener("click",()=>{type.value="";category.value="";loadTransactions()});
loadTransactions();
