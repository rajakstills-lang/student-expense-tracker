let categoryChart, dailyChart;
const money = n => "₹" + Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});

async function loadDashboard(){
  const d = await (await fetch("/api/dashboard")).json();
  document.getElementById("totalIncome").textContent = money(d.total_income);
  document.getElementById("totalExpense").textContent = money(d.total_expense);
  document.getElementById("budget").textContent = money(d.budget);
  document.getElementById("remaining").textContent = money(d.remaining);
  document.getElementById("percent").textContent = d.percentage_used.toFixed(0) + "%";
  const width = Math.min(d.percentage_used,100);
  document.getElementById("progressBar").style.width = width + "%";
  document.getElementById("statusText").textContent = d.message;

  let alert = "";
  if(d.status === "critical"){
    alert = `<div class="alert alert-warning shadow-sm"><strong>⚠️ Budget Alert!</strong> You have reached ${d.percentage_used.toFixed(0)}% of your monthly budget. Remaining: ${money(d.remaining)}</div>`;
  } else if(d.status === "exceeded"){
    alert = `<div class="alert alert-danger shadow-sm"><strong>🚨 Budget Exceeded!</strong> You have exceeded your budget by ${money(Math.abs(d.remaining))}.</div>`;
  } else if(d.status === "no-budget"){
    alert = `<div class="alert alert-info shadow-sm"><strong>Set your monthly budget.</strong> Go to Monthly Budget to begin tracking progress.</div>`;
  }
  document.getElementById("budgetAlert").innerHTML = alert;
}

async function loadCategoryChart(){
  const rows = await (await fetch("/api/category-summary")).json();
  const empty = document.getElementById("categoryEmpty");
  if(!rows.length){ empty.classList.remove("d-none"); return; }
  const ctx = document.getElementById("categoryChart");
  categoryChart?.destroy();
  categoryChart = new Chart(ctx,{type:"doughnut",data:{labels:rows.map(x=>x.category),datasets:[{data:rows.map(x=>x.amount)}]},options:{responsive:true,plugins:{legend:{position:"bottom"}}}});
}

async function loadDailyChart(){
  const rows = await (await fetch("/api/monthly-summary")).json();
  const ctx = document.getElementById("dailyChart");
  dailyChart?.destroy();
  dailyChart = new Chart(ctx,{type:"bar",data:{labels:rows.map(x=>x.day),datasets:[{label:"Daily Expense (₹)",data:rows.map(x=>x.amount)}]},options:{responsive:true,scales:{y:{beginAtZero:true}}}});
}

async function loadRecent(){
  const rows = await (await fetch("/api/transactions")).json();
  const body = document.getElementById("recentBody");
  body.innerHTML = rows.slice(0,8).map(x=>`<tr><td>${x.date}</td><td><span class="badge ${x.type==="income"?"badge-income":"badge-expense"}">${x.type}</span></td><td>${x.category}</td><td>${x.note||"-"}</td><td class="text-end fw-semibold">${x.type==="income"?"+":"-"}${money(x.amount)}</td></tr>`).join("") || `<tr><td colspan="5" class="text-center text-muted">No transactions yet.</td></tr>`;
}

async function loadInsight(){
  const x = await (await fetch("/api/insight")).json();
  document.getElementById("insight").textContent = x.insight;
}
Promise.all([loadDashboard(),loadCategoryChart(),loadDailyChart(),loadRecent(),loadInsight()]);
