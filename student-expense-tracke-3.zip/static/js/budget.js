const month = document.getElementById("month");
const year = document.getElementById("year");
const amount = document.getElementById("amount");
const form = document.getElementById("budgetForm");
const message = document.getElementById("budgetMessage");
const names = ["January","February","March","April","May","June","July","August","September","October","November","December"];
names.forEach((n,i)=>month.insertAdjacentHTML("beforeend",`<option value="${i+1}">${n}</option>`));
const now = new Date();
month.value = now.getMonth()+1;
year.value = now.getFullYear();

async function loadBudget(){
  const d = await (await fetch(`/api/budget?month=${month.value}&year=${year.value}`)).json();
  amount.value = d.amount || "";
}
month.addEventListener("change",loadBudget);
year.addEventListener("change",loadBudget);
loadBudget();

form.addEventListener("submit",async e=>{
  e.preventDefault();
  const res = await fetch("/api/budget",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
    amount:amount.value,month:month.value,year:year.value
  })});
  const d = await res.json();
  message.innerHTML = `<div class="alert alert-${res.ok?"success":"danger"}">${d.message||d.error}</div>`;
});
