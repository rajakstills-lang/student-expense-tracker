const typeEl = document.getElementById("type");
const categoryEl = document.getElementById("category");
const dateEl = document.getElementById("date");
const form = document.getElementById("transactionForm");
const msg = document.getElementById("formMessage");

const expenseCategories = ["Food","Travel","Education","Rent","Shopping","Entertainment","Bills","Health","Personal","Other"];
const incomeCategories = ["Allowance","Salary","Scholarship","Part-time Job","Other"];

function loadCategories(){
  const list = typeEl.value === "income" ? incomeCategories : expenseCategories;
  categoryEl.innerHTML = list.map(x => `<option value="${x}">${x}</option>`).join("");
}
typeEl.addEventListener("change", loadCategories);
dateEl.value = new Date().toISOString().slice(0,10);
loadCategories();

form.addEventListener("submit", async (e)=>{
  e.preventDefault();
  const payload = {
    type:typeEl.value, amount:document.getElementById("amount").value,
    category:categoryEl.value, date:dateEl.value, note:document.getElementById("note").value
  };
  const res = await fetch("/api/transactions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const data = await res.json();
  msg.innerHTML = `<div class="alert alert-${res.ok?"success":"danger"}">${data.message || data.error}</div>`;
  if(res.ok) setTimeout(()=>location.href="/dashboard",700);
});
